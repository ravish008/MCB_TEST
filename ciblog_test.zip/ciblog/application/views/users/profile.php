<?php //echo validation_errors(); ?>
<style type="text/css">
	.form-inline .form-control {
    display: inline-block !important;
    width: 20px !important;
    /* vertical-align: middle; */
}
.container{
	background-image: url("assets/images1.jpg");
}
.step-right{
	padding: 99px;
}
</style>

<?php echo form_open('users/profile'); ?>
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
			<h1 class="text-center"><?= $title; ?></h1>
			<div class="form-group">
				<label class="control-label">Name</label>
				<input type="text" class="form-control" name="name" readonly="true" placeholder="Name" value="<?php echo $user['name']; ?>">
			</div>
			<div class="form-group">
				<label>zipcode</label>
				<input type="text" class="form-control" name="zipcode" readonly="true" placeholder="Zipcode" value="<?php echo $user['zipcode']; ?>">
			</div>
			<div class="form-group">
				<label class="control-label">Email</label>
				<input type="email" class="form-control" name="email" readonly="true" placeholder="Email" value="<?php echo $user['email']; ?>">
			</div>
			<div class="form-group">
				<label class="control-label">Username</label>
				<input type="text" class="form-control" name="username" readonly="true" placeholder="Username" value="<?php echo $user['username']; ?>">
			</div>
	
			
		<!--	<button type="submit" class="btn btn-primary btn-block">EDIT</button>-->
<button class="btn btn-primary btn-block" onClick="window.location.href = '<?php echo base_url();?>users/edit';return false;">Edit</button>

 		</div>

 			<div class="col-md-4">
    				<a href="https://placeholder.com"><img src="<?php echo base_url().'uploads/'.$user['image_url']; ?>" class="step-right" width="400" height="400"></a>
			</div>

	</div>
<?php echo form_close(); ?>
