<?php //echo validation_errors(); ?>
<style type="text/css">
	.form-inline .form-control {
    display: inline-block !important;
    width: 20px !important;
    /* vertical-align: middle; */
}
.container{
	background-image: url("assets/images1.jpg");
}
</style>
<?php echo form_open('users/register'); ?>
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
		<input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>">

			<h1 class="text-center"><?= $title; ?></h1>
			<div class="form-group">
				<label class="control-label">Name</label>
				<input type="text" class="form-control" value="<?php echo set_value('name', ''); ?>" name="name" placeholder="name">
				<span class="help-block has-danger"><?php echo form_error('name'); ?></span>
			</div>
			<div class="form-group">
				<label>Zipcode</label>
				<input type="text" class="form-control" value="<?php echo set_value('zipcode', ''); ?>" name="zipcode" placeholder="Zipcode">
			</div>
			<div class="form-group">
				<label class="control-label">Email</label>
				<input type="email" class="form-control" value="<?php echo set_value('email', ''); ?>" name="email" placeholder="Email">
				<span class="help-block has-danger"><?php echo form_error('email'); ?></span>
			</div>
			<div class="form-group">
				<label class="control-label">Username</label>
				<input type="text" class="form-control" value="<?php echo set_value('username', ''); ?>" name="username" placeholder="Username">
				<span class="help-block has-danger"><?php echo form_error('username'); ?></span>
			</div>
			<div class="form-group">
				<label class="control-label">Password</label>
				<input type="password" class="form-control" value="<?php echo set_value('password', ''); ?>" name="password" placeholder="Password">
				<span class="help-block has-danger"><?php echo form_error('password'); ?></span>
			</div>
			<div class="form-group">
				<label class="control-label">Confirm Password</label>
				<input type="password" class="form-control" value="<?php echo set_value('password2', ''); ?>" name="password2" placeholder="Confirm Password">
				<span class="help-block has-danger"><?php echo form_error('password2'); ?></span>
			</div>
			<div class="col-md-4">	
				<div class="form-inline">
					<label class="control-label">Admin</label>
					<input type="checkbox" class="form-control" name="admin">
				</div>
			</div>
			<button type="submit" class="btn btn-primary btn-block">Submit</button>
		</div>
	</div>
<?php echo form_close(); ?>
