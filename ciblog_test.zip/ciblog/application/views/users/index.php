<script type="text/javascript">
$(document).ready(function() {
    $('.table').DataTable();
});
</script>
<style type="text/css">
	.table tr{
		background-color: #e8d7d7;
	}
td:nth-child(even) {background-color: : #CCC !important}
td:nth-child(odd) {background-color: : #FFF !important}
</style>
<?php if($this->session->userdata('admin')): ?>
<table class="table table-striped table-responsive">
<thead>
<tr>
<td>Name</td>
<td>UserName</td>
<td>ZipCode</td>
<td>Register Date</td>
</tr>
</thead>
<?php foreach($users as $user) : ?>
	<tr>
		<td><?php echo $user->name ?></td>
		<td><?php echo $user->username ?></td>
		<td><?php echo $user->zipcode ?></td>
		<td><?php echo $user->register_date ?></td>
	</tr>
<?php endforeach; ?>
</table>
<?php endif; ?>
<tbody>
</tbody>
</table>