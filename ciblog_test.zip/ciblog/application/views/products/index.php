	<style>
	.filter-panel{width:100%;}
	.filter-panel p{margin-right: 30px;float: left;}
	.list-item{
	    float: left;
	    width: 15%;
	    height: 80px;
	    padding: 10px;
	    border: 2px solid #333;
	    margin: 10px 10px 10px 0px;
	}
	.list-item h2{margin: 0;}
	</style>

	<div class="container">
		<?php 
			 if(!empty($msg)){
		     	echo $msg;
		     }
		?>
		<?php if (!empty($products)): ?>
	   

	    <div id="productContainer">

	<?php foreach($products as $product) : ?>
        		<div class="col-md-4 pull-left">
              <div class="thumbnail">
                <img src="http://tech.firstpost.com/wp-content/uploads/2014/09/Apple_iPhone6_Reuters.jpg" alt="" class="img-responsive">
                <div class="caption">
                  <h4 class="pull-right"><?php echo $product["price"]; ?></h4>
                  <h4><a href="#"><?php echo $product["name"]; ?></a></h4>
                  <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>
                </div>
                <div class="ratings">
                  <p>
                    <span class="glyphicon glyphicon-star"></span>
                    <span class="glyphicon glyphicon-star"></span>
                    <span class="glyphicon glyphicon-star"></span>
                    <span class="glyphicon glyphicon-star"></span>
                    <span class="glyphicon glyphicon-star"></span>
                     (15 reviews)
                  </p>
                </div>
                <div class="space-ten"></div>
                <div class="btn-ground text-center">
                    <button type="button" class="btn btn-primary"><i class="fa fa-shopping-cart"></i> Add To Cart</button>
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#product_view"><i class="fa fa-search"></i> Quick View</button>
                </div>
                <div class="space-ten"></div>
              </div>
            </div>
     
	
	<?php endforeach; ?>  
	    </div>
	    <?php endif; ?>
	</div>
	<script type="text/javascript">
		var baseurl = "<?php print base_url(); ?>";

	      $('.price_range').jRange({
	          from: 0,
	          to: 500,
	          step: 50,
	          format: '%s USD',
	          width: 300,
	          showLabels: true,
	          isRange : true
	      });
	    
	</script>

	<script>
	function filterProducts() {
	    var price_range = $('.price_range').val();
	    $.ajax({
	        type: 'POST',
	        url: baseurl+"products/getProducts",
	        data:'price_range='+price_range,
	        beforeSend: function () {
	            $('.container').css("opacity", ".5");
	        },
	        success: function (html) {
	            $('#productContainer').html(html);
	            $('.container').css("opacity", "");
	        }
	    });
	}
	</script>