
<?php 
	if(isset($error) && !empty($error))
	{
		echo '<div class="alert alert-danger">'.$error."</div>"; 
	}
	else
	{
		$this->session->unset_userdata('upload_success');
	}

?>

<?php echo form_open_multipart('upload/xml_upload');?>

<!-- <input type="file" name="userfile" size="20" />

<br /><br />

<input type="submit" value="upload" /> -->

<div class="container">       
        <h3>Upload XML File</h3>
	<!-- COMPONENT START -->
	<div class="form-group">
		<div class="input-group input-file" name="xmlfile">
    		<input type="text" class="form-control" placeholder='Choose a file...' />			
            <span class="input-group-btn">
        		<button class="btn btn-default btn-choose" type="button">Choose</button>
    		</span>


		</div>
	</div>
	<!-- COMPONENT END -->
	<div class="form-group">
		<button type="submit" class="btn btn-primary pull-right">Upload</button>
		<button type="reset" class="btn btn-danger">Reset</button>
	</div>
</div>
</div>
<script type="text/javascript">
	
	function bs_input_file() {
	$(".input-file").before(
		function() {
			if ( ! $(this).prev().hasClass('input-ghost') ) {
				var element = $("<input type='file' class='input-ghost' style='visibility:hidden; height:0'>");
				element.attr("name",$(this).attr("name"));
				element.change(function(){
					element.next(element).find('input').val((element.val()).split('\\').pop());
				});
				$(this).find("button.btn-choose").click(function(){
					element.click();
				});
				$(this).find("button.btn-reset").click(function(){
					element.val(null);
					$(this).parents(".input-file").find('input').val('');
				});
				$(this).find('input').css("cursor","pointer");
				$(this).find('input').mousedown(function() {
					$(this).parents('.input-file').prev().click();
					return false;
				});
				return element;
			}
		}
	);
}
$(function() {
	bs_input_file();
});
</script>
<?php echo form_close(); ?>