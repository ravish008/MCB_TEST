 <h2><?= $title; ?></h2><br>
 <div class="col-md-4 pull-left">
 <div class="filter-panel">
        <p><input type="hidden" class="price_range" value="0,500" /></p>
        <input type="button" class="btn btn-primary" onclick="filterProducts()" value="FILTER" />
    </div>
    </div>