<?php
	class Users extends CI_Controller{
		//view all users if user is admin
		 public function index()
	     {

	     	//var_dump($users);
	     	if($this->session->userdata('admin')){
	     		 $data['users'] = $this->user_model->getAllUsers();
		         $this->load->view('templates/header');
				 $this->load->view('users/index', $data);
				 $this->load->view('templates/footer');
	     	}else{
	     		//$this->logout();
	     		$this->session->set_flashdata('admin_loggedin', 'You must logged in as an admin to have access to this page');
	     		redirect('users/login');
	     	}
			
	     }
			// Register user
		public function register(){
			$data['title'] = 'Sign Up';

			$this->form_validation->set_rules('name', 'Name', 'required');
			$this->form_validation->set_rules('username', 'Username', 'required|callback_check_username_exists');
			$this->form_validation->set_rules('email', 'Email', 'required|callback_check_email_exists');
			$this->form_validation->set_rules('password', 'Password', 'required');
			$this->form_validation->set_rules('password2', 'Confirm Password', 'matches[password]');



			if($this->form_validation->run() === FALSE){
				$this->load->view('templates/header');
				$this->load->view('users/register', $data);
				$this->load->view('templates/footer');
			} else {
				// Encrypt password
				$enc_password = md5($this->input->post('password'));

				$this->user_model->register($enc_password);

				// Set message
				$this->session->set_flashdata('user_registered', 'You are now registered and can log in');


				redirect('posts');
			}
		}

		//crreate user profile
		public function profile(){
			$data['title'] = 'View Profile';
			$user_id = $this->session->userdata('user_id');
			//var_dump(base_url()."assets/images");die;
			if($this->session->userdata('user_id')){
				$data['user'] = $this->user_model->get_user_data($user_id);
				if ($this->session->userdata('user_id') == $user_id){
				$this->load->view('templates/header');
				$this->load->view('users/profile', $data);
				$this->load->view('templates/footer');
			 }
			}else

		   redirect('users/login');
			
		}
		//edit user profile
		public function edit(){
			$data['title'] = 'Edit Profile';
			$user_id = $this->session->userdata('user_id');
			if($this->session->userdata('user_id')){
				$data['user'] = $this->user_model->get_user_data($user_id);
					$name = $this->input->post('name');
					$zipcode = $this->input->post('zipcode');
					$email = $this->input->post('email');
					$username = $this->input->post('username');
				//print($this->encrypt->decode( $user['password']));

				if ($this->session->userdata('user_id') == $user_id){
						if(!empty($name) || !empty($zipcode) || !empty($username) || !empty($name)){
						
						if($this->user_model->updateuser($user_id)){
							// Set message
						$this->session->set_flashdata('update', 'Changes have been updated!');
						redirect('users/profile');	
						};
											
					}
				$this->load->view('templates/header');
				$this->load->view('users/edit', $data);
				$this->load->view('templates/footer');
			 }
			}else
		   redirect('users/profile');			
		}
		
		//upload image for the user
		public function doupload()
	     {
	        $upload_path= base_url()."/assets/images" ;
	        $user_id = $this->session->userdata('user_id'); 
	      //  $uid='10'; //creare seperate folder for each user 
	        $upPath=$upload_path."/".$user_id;
	        if(!file_exists($upPath)) 
	        {
	                   mkdir($upPath, 0777, true);
	        }
	        $config = array(
	        'upload_path' => $upPath,
	        'allowed_types' => "gif|jpg|png|jpeg",
	        'overwrite' => TRUE,
	        'max_size' => "2048000", 
	        'max_height' => "768",
	        'max_width' => "1024"
	        );
	        $this->load->library('upload', $config);
	        if(!$this->upload->do_upload('userpic'))
	        { 
	            $data['imageError'] =  $this->upload->display_errors();

	        }
	        else
	        {
	            $imageDetailArray = $this->upload->data();
	            $image =  $imageDetailArray['file_name'];
	        }

	     }

		// Log in user
		public function login(){
			$data['title'] = 'Sign In';

			$this->form_validation->set_rules('username', 'Username', 'required');
			$this->form_validation->set_rules('password', 'Password', 'required');

			if($this->form_validation->run() === FALSE){
				$this->load->view('templates/header');
				$this->load->view('users/login', $data);
				$this->load->view('templates/footer');
			} else {
				
				// Get username
				$username = $this->input->post('username');
				// Get and encrypt the password
				$password = md5($this->input->post('password'));

				// Login user
				$user_id = $this->user_model->login($username, $password);
				$admin = $this->is_admin($user_id);
				$check_valid_login = $this->user_model->verify_user($username, $password);	
				

				if($user_id && $check_valid_login !== false){

					// Create session
					$user_data = array(
						'user_id' => $user_id,
						'username' => $username,
						'logged_in' => true,
						'admin' => $admin
					);


					$this->session->set_userdata($user_data);

					// Set message
					$this->session->set_flashdata('user_loggedin', 'You are now logged in');
					
					redirect('posts');
				} else {

					$checked_login = $this->user_model->chk_lock($this->input->post('username'));
					if($checked_login->locked_status == 'yes'){
						// Set message
						$this->session->set_flashdata('user_blocked', 'User account has been locked due to 3 unsuccessful logins');
					}else{
						// Set message
					$this->session->set_flashdata('login_failed', 'Login is invalid');
					}	
					

					redirect('users/login');
				}
				
			}
		}

		// Log user out
		public function logout(){
			// Unset user data
			$this->session->unset_userdata('logged_in');
			$this->session->unset_userdata('user_id');
			$this->session->unset_userdata('username');
			$this->session->unset_userdata('admin');

			// Set message
			$this->session->set_flashdata('user_loggedout', 'You are now logged out');

			redirect('users/login');
		}

		// Check if username exists
		public function check_username_exists($username){
			$this->form_validation->set_message('check_username_exists', 'That username is taken. Please choose a different one');
			if($this->user_model->check_username_exists($username)){
				return true;
			} else {
				return false;
			}
		}

		// Check if email exists
		public function check_email_exists($email){
			$this->form_validation->set_message('check_email_exists', 'That email is taken. Please choose a different one');
			if($this->user_model->check_email_exists($email)){
				return true;
			} else {
				return false;
			}
		}

		public function	is_admin($userID){
			$admin = $this->user_model->is_admin($userID);
			return $admin;
		}
		

	}