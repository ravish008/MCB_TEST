<?php
error_reporting(0);
class Upload extends CI_Controller {

        public function __construct()
        {
                parent::__construct();
                $this->load->helper(array('form', 'url'));
                $this->load->library('excel');
        }
		
        public function index()
        {
                $this->load->view('templates/header');
                $this->load->view('upload/upload_form', array('error' => ' ' ));
                $this->load->view('templates/footer');
        }
		private static function calc_age($date)
		{
		   return((int)date_diff(date_create($date),date_create('today'))->y);
		}
		public function xml_upload(){
				$config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'xml';
          
			$this->load->library('upload', $config);
                   				
                if ( ! $this->upload->do_upload('xmlfile'))
                {       

                        $error = array('error' => $this->upload->display_errors());
                       $this->load->view('templates/header');
                        $this->load->view('upload/upload_xml',$error);
                        $this->load->view('templates/footer');
                        
					//	var_dump($config['allowed_types']);
                }
                else
                {
                       //var_dump($this->load->library('upload', $config));
						//$xmlraw = file_get_contents();
						$filename = $_FILES['xmlfile']['name'];
						//var_dump($filename);
						 copy($_FILES['xmlfile']['tmp_name'], './assets/' .$filename);
						 $xmlfile = "./assets/" .$filename;
						$xmlRaw = file_get_contents($xmlfile);
						 $this->load->library('simplexml');
						 $xmlData = $this->simplexml->xml_parse($xmlRaw);
						 $data = json_encode($xmlData);
						 $array = json_decode($data,TRUE); 

						   foreach ( $xmlData['Doc_Data']['DataItem_Customer'] as $val ) {
							   $customer_id = $val['customer_id'];
							   $customer_type = $val['Customer_Type'];						 
							   $dob = $val['Date_Of_Birth'];
							   $dob = str_replace('/', '-', $dob);
							$dob = date('Y-m-d', strtotime($dob));
							 $date_of_birth=date("Y-m-d", strtotime($dob));
							   $address_1 = $val['Mailing_Address']['Address_Line1'];
							   $address_2 = $val['Mailing_Address']['Address_Line2'];
							   $town_city = $val['Mailing_Address']['Town_City'];
							   $country = $val['Mailing_Address']['Country'];
							   $contact_name = $val['Contact_Details']['Contact_Name'];
							   $contact_number = $val['Contact_Details']['Contact_Number'];
							   $num_shares = $val['Shares_Details']['Num_Shares'];
							   $share_price = $val['Shares_Details']['Share_Price'];
							   $date_Incorp = $val['Date_Incorp'];
							   $date_Incorp = str_replace('/', '-', $date_Incorp);
								$date_Incorp = date('Y-m-d', strtotime($date_Incorp));
								$Incorp_date=date("Y-m-d", strtotime($date_Incorp));
							   $registration_no = $val['Registration_No'];
							   
								$date = DateTime::createFromFormat('d/m/Y', "19/07/1987");
							//echo (date("Y-m-d") - $date->format('Y-m-d'));

							//$dob = new DateTime($date);
							$today = new DateTime;
							$age = $today->diff($date);
							$age = $age->format('%y');
							   if($customer_type == "Individual" && $age >= 18){
								   $this->db->set('Customer_Id',$customer_id);
							$this->db->set('Customer_Type',$customer_type);
							$this->db->set('Date_Of_Birth',$date_of_birth);
							$this->db->set('Date_Incorp',$Incorp_date);
							$this->db->set('Registration_No',$registration_no);
							$this->db->set('Address_Line_1',$address_1);
							$this->db->set('Address_Line_2',$address_2);
							$this->db->set('Town_City',$town_city);
							$this->db->set('Country', $country);
							$this->db->set('Contact_Name', $contact_name);
							$this->db->set('Contact_Number',$contact_number);
							$this->db->set('Num_Shares',$num_shares);
							$this->db->set('Share_Price',$share_price);
							$this->db->insert('customer_details');
														
							   }else{
								       $error = "Invalid Age,must be greater than 18";
									   $this->db->set('error_message',$error);
									    $this->db->set('customer_id',$customer_id);
									   $this->db->insert('error_logs');

							   }
							   	   if($customer_type == "Corporate" && is_numeric($num_shares) > 0){
								   $this->db->set('Customer_Id',$customer_id);
							$this->db->set('Customer_Type',$customer_type);
							$this->db->set('Date_Of_Birth',$date_of_birth);
							$this->db->set('Date_Incorp',$Incorp_date);
							$this->db->set('Registration_No',$registration_no);
							$this->db->set('Address_Line_1',$address_1);
							$this->db->set('Address_Line_2',$address_2);
							$this->db->set('Town_City',$town_city);
							$this->db->set('Country', $country);
							$this->db->set('Contact_Name', $contact_name);
							$this->db->set('Contact_Number',$contact_number);
							$this->db->set('Num_Shares',$num_shares);
							$this->db->set('Share_Price',$share_price);
							$this->db->insert('customer_details');
							   }else{

								       $error = "number of shares must be number and greater than zero";
									   $this->db->set('error_message',$error);
									    $this->db->set('customer_id',$customer_id);
									   $this->db->insert('error_logs');
										
							   }

							
						 } 
										header("HTTP/1.1 200 OK");
										http_response_code(201);
										header("Status: 200 All rosy");
										print("Data Inserted Successfully");

			               
                }
			
		}
        public function do_upload()
        {
                               

                $config['upload_path']          = './uploads/';
                $config['allowed_types']        = 'gif|jpg|png|jfif';
                $config['max_size']             = 10000;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

                $this->load->library('upload', $config);
                if ( ! $this->upload->do_upload('userfile'))
                {       

                        $error = array('error' => $this->upload->display_errors());
                        $this->load->view('templates/header');
                        $this->load->view('upload/upload_form',$error);
                        $this->load->view('templates/footer');
                        
					//	var_dump($config['allowed_types']);
                }
                else
                {
                        if($this->session->userdata('user_id'))
                        {
                                $data = array('upload_data' => $this->upload->data());
                                $user_id = $this->session->userdata('user_id'); 
                                $image = $this->upload->data();
                                $image_flag =  $this->user_model->save_url($user_id,$image['file_name']);

                                if($image_flag)
                                {
                                        $this->session->set_flashdata('upload_success', 'Your picture has been succesfully uploaded');
                                        unset($error);
                                }


                                $this->load->view('templates/header');
                                $this->load->view('upload/upload_form', $data);
                                $this->load->view('templates/footer');   
                        }
                                       
                }
        }

        public function generate_worksheet(){
                $this->excel->setActiveSheetIndex(0);
        //name the worksheet
        $this->excel->getActiveSheet()->setTitle('test worksheet');
        //set cell A1 content with some text
        $this->excel->getActiveSheet()->setCellValue('A1', 'This is just some text value');
        //change the font size
        $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(20);
        //make the font become bold
        $this->excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(true);
        //merge cell A1 until D1
        $this->excel->getActiveSheet()->mergeCells('A1:D1');
        //set aligment to center for that merged cell (A1 to D1)
        $this->excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

        $filename='just_some_random_name.xls'; //save our workbook as this file name
        header('Content-Type: application/vnd.ms-excel'); //mime type
        header('Content-Disposition: attachment;filename="'.$filename.'"'); //tell browser what's the file name
        header('Cache-Control: max-age=0'); //no cache
                     
        //save it to Excel5 format (excel 2003 .XLS file), change this to 'Excel2007' (and adjust the filename extension, also the header mime type)
        //if you want to save it as .XLSX Excel 2007 format
        $objWriter = PHPExcel_IOFactory::createWriter($this->excel, 'Excel5');  
        //force user to download the Excel file without writing it to server's HD
        $objWriter->save('php://output');
        }


}

?>