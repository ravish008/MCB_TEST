<?php
defined('BASEPATH') OR exit('No direct script access allowed');


require APPPATH . 'libraries\RestController.php';

class Api extends RestController
{
       public function __construct() {
               parent::__construct();
               $this->load->model('user_model');
			   $this->load->model('employee_model');
			   $this->load->model('customer_model');
       }    
       public function user_get($id=0){
		   if(!empty($id)){
			 $r = $this->user_model->getById($id);
			 $this->response($r,RestController::HTTP_OK);			
		   }else
		   {
			 $r = $this->user_model->read();
			$this->response($r,RestController::HTTP_OK);
		   } 
       }
	   
       public function user_put(){
           $id = $this->uri->segment(3);
           $data = array('name' => $this->input->get('name'),
           'pass' => $this->input->get('pass'),
           'type' => $this->input->get('type')
           );
            $r = $this->user_model->update($id,$data);
               $this->response($r,RestController::HTTP_OK); 
       }
       public function user_post(){
           $data = array('name' => $this->input->post('name'),
           'pass' => $this->input->post('pass'),
           'type' => $this->input->post('type')
           );
           $r = $this->user_model->insert($data);
           $this->response($r,RestController::HTTP_OK); 
       }
       public function user_delete(){
           $id = $this->uri->segment(3);
           $r = $this->user_model->delete($id);
           $this->response($r,RestController::HTTP_OK); 
       }
	    public function employees_get($id=0){
		   if(!empty($id)){
			 $r = $this->employee_model->getById($id);
			 if($r){
				 $this->response($r,RestController::HTTP_OK);			
			 }else{
				 $this->response($r,RestController::HTTP_BAD_REQUEST);			

			 }
		   }else
		   {
			 $r = $this->employee_model->read();
			$this->response($r,RestController::HTTP_OK);
		   }
      
       }

	public function employees_put(){
           $id = $this->uri->segment(3);
           $data = array('first_name' => $this->input->get('first_name'),
           'last_name' => $this->input->get('last_name'),
           'email' => $this->input->get('email'),'telephone_number' => $this->input->get('telephone_number'),
		   'address' => $this->input->get('address'),'position_name' => $this->input->get('position_name')
           );
            $r = $this->employee_model->update($id,$data);
               $this->response($r,RestController::HTTP_OK); 
       }
       public function employees_post(){
           $data = array('first_name' => $this->input->get('first_name'),
           'last_name' => $this->input->get('last_name'),
           'email' => $this->input->get('email'),'telephone_number' => $this->input->get('telephone_number'),
		   'address' => $this->input->get('address'),'position_name' => $this->input->get('position_name')
           );
           $r = $this->employee_model->insert($data);
           $this->response($r,RestController::HTTP_OK); 
       }
       public function employees_delete(){
           $id = $this->uri->segment(3);
           $r = $this->employee_model->delete($id);
           $this->response($r,RestController::HTTP_OK); 
       }
	   	public function customer_put(){
           $id = $this->uri->segment(3);
           $data = array('Customer_Type' => $this->input->get('Customer_Type'),
           'Date_Of_Birth' => $this->input->get('Date_Of_Birth'),
           'Date_Incorp' => $this->input->get('Date_Incorp'),'Registration_No' => $this->input->get('Registration_No'),
		   'Address_Line_1' => $this->input->get('Address_Line_1'),'Address_Line_2' => $this->input->get('Address_Line_2'),
		   'Town_City' => $this->input->get('Town_City'),'Country' => $this->input->get('Country'),'Contact_Name' => $this->input->get('Contact_Name'),'Contact_Number' => $this->input->get('Contact_Number'),'Num_Shares' => $this->input->get('Num_Shares'),'Share_Price' => $this->input->get('Share_Price')
           );
            $r = $this->employee_model->update($id,$data);
               $this->response($r,RestController::HTTP_OK); 
       }
	    public function customer_get($id=0){
		   if(!empty($id)){
			 $r = $this->customer_model->getById($id);
			 if($r){
				 $this->response($r,RestController::HTTP_OK);			
			 }else{
				 $this->response($r,RestController::HTTP_BAD_REQUEST);			

			 }
		   }else
		   {
			 $r = $this->customer_model->read();
			$this->response($r,RestController::HTTP_OK);
		   }
			if($this->get('name')){
				 $keyword = $this->get('name');
   
			$msgEmpty = ['status' => false, 'message' => 'Data Not Found'];
			if ($keyword === null) {
				$str =  $this->customer_model->showCustomer();
			} else {
				$str = $this->customer_model->showCustomer($keyword);
			}
			if ($str) {
				$this->set_response([
					'status' => true,
					'data' => $str,
				], 200);
			} else {
				$this->set_response($msgEmpty, 404);
			}
		}
}			
      
       
	   public function search_get()
{
    $keyword = $this->get('name');
   // $keyword = $this->get('nama');
    /*  $qs = $_SERVER['QUERY_STRING'];
    $ru = $_SERVER['REQUEST_URI'];
    $pp = substr($ru, strlen($qs)+1);
    parse_str($pp, $_GET);

    echo "<pre>";
    print_r($_GET);
    echo "</pre>"; */
    $msgEmpty = ['status' => false, 'message' => 'Data Not Found'];
    if ($keyword === null) {
        $str =  $this->customer_model->showCustomer();
    } else {
        $str = $this->customer_model->showCustomer($keyword);
    }
    if ($str) {
        $this->set_response([
            'status' => true,
            'data' => $str,
        ], 200);
    } else {
        $this->set_response($msgEmpty, 404);
    }
	
}
    
}