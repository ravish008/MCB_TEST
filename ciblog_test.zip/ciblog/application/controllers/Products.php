<?php
class Products extends CI_Controller {

	public function __construct()
    {
            parent::__construct();
            $this->load->helper(array('form', 'url'));
            $this->load->model('product_model');
    }

    public function index(){

			$data['title'] = 'Latest Products';

			$data['products'] = $this->product_model->get_products();

			$this->load->view('templates/header');
			$this->load->view('templates/filter',$data);
			$this->load->view('products/index', $data);
			$this->load->view('templates/footer');
    }

     public function getProducts(){

     		if(!empty($_REQUEST)){
 				$priceRange = $this->input->post('price_range');
 				if(!empty($priceRange)){
 					 $priceRangeArr = explode(',', $priceRange);
	 	     		$data['products'] = $this->product_model->filter_products($priceRangeArr[0],$priceRangeArr[1]);
	 	     		if(empty($this->product_model->filter_products($priceRangeArr[0],$priceRangeArr[1]))){
	 	     			$data['msg'] = "Product(s) not found!";
	 	     		}
		 	     		$this->load->view('products/index', $data);

 				}	
 				
     		}

     }


}

