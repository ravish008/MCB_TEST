<?php
	class User_model extends CI_Model{
		public function register($enc_password){
			// User data array
			$data = array(
				'name' => $this->input->post('name'),
				'email' => $this->input->post('email'),
                'username' => $this->input->post('username'),
                'password' => $enc_password,
                'zipcode' => $this->input->post('zipcode'),
                'admin' => $this->input->post('admin') ? 1:0
			);

			// Insert user
			return $this->db->insert('users', $data);
		}

		// Log user in
		public function login($username, $password){
			// Validate
			$this->db->where('username', $username);
			$this->db->where('password', $password);

			$result = $this->db->get('users');

			if($result->num_rows() == 1){
				return $result->row(0)->id;
			} else {
				return false;
			}
		}

		// Check username exists
		public function check_username_exists($username){
			$query = $this->db->get_where('users', array('username' => $username));
			if(empty($query->row_array())){
				return true;
			} else {
				return false;
			}
		}

		// Check email exists
		public function check_email_exists($email){
			$query = $this->db->get_where('users', array('email' => $email));
			if(empty($query->row_array())){
				return true;
			} else {
				return false;
			}
		}

		public function getUser($userID)
		{
			$query = $this->db->get_where('users', array('id' => $userID));
			$result =  $query->row_array();
			return $result['id'];
		}

		public function	is_admin($userID){
			$query = $this->db->get_where('users', array('id' => $userID));
			$result =  $query->row_array();
			return $result['admin'];
		}

		public function getAllUsers(){
			$query = $this->db->get('users');
			return $query->result();
		}

		 //Check post user data
    public function verify_user($username, $password) {
    	
      $q = $this -> db -> where('username', $username) -> where('password', $password) -> where('locked_status !=', "yes") -> limit(1) -> get('users');
       if ($q -> num_rows() > 0) {
            // person has account with us
            return $q -> row();
        } else {
            $q = $this -> db -> where('username', $username) -> limit(1) -> get('users');
            $user_row = $q -> row(); 
            if ( $user_row->login_attempt >= 2) {
                //Lock the user out
                $this->db->set('locked_status', '"yes"', FALSE);
                $this->db->where('username', $username)->update('users');
                
                return false;
            } else {
                // failed login set attempt +1
                $this->db->set('login_attempt', 'login_attempt+1', FALSE);
                $this->db->where('username', $username)->update('users');
                
                return false;                
            }
        } 
        return false;
    }

    //Check for the user is locked or not
	    public function chk_lock($username) {

	         $q = $this -> db -> where('username', $username) -> where('locked_status = "yes" ') -> limit(1) -> get('users');  
	         if ($q -> num_rows() > 0) {
	            // person locked
	            return  $q -> row();
	        }
	        return false;
	    }

	    //get userdata through userid

	    public function get_user_data($userID){
    		$query = $this->db->get_where('users', array('id' => $userID));
			$result =  $query->row_array();
			return $result;
	    }

	    //save image path through userid

	    public function save_url($userID,$path){
    	      $this->db->set('image_url', $path);
              $this->db->where('id', $userID)->update('users');
              return true;
	    }
		
		public function read(){
		   $query = $this->db->query("select * from tbl_user");
		   return $query->result_array();
		}
	   public function getById($id){
			$query = $this->db->get_where('tbl_user', array('user_id' => $id));
			$result =  $query->row_array();
			return $result;
	   }
   public function insert($data){
       
       $this->user_name    = $data['name']; // please read the below note
       $this->user_password  = $data['pass'];
       $this->user_type = $data['type'];
       if($this->db->insert('tbl_user',$this))
       {    
           return 'Data is inserted successfully';
       }
         else
       {
           return "Error has occured";
       }
   }
   public function update($id,$data){
   
      $this->user_name    = $data['name']; // please read the below note
       $this->user_password  = $data['pass'];
       $this->user_type = $data['type'];
       $result = $this->db->update('tbl_user',$this,array('user_id' => $id));
       if($result)
       {
           return "Data is updated successfully";
       }
       else
       {
           return "Error has occurred";
       }
   }
 public function updateuser ($id,$name='null',$zipcode='null',$email='null',$username='null'){
	// User data array
			$data = array(
				'name' => $this->input->post('name'),
				'zipcode' => $this->input->post('zipcode'),
                'email' => $this->input->post('email'),
                'username' => $this->input->post('username')
			);
			
	   $this->name  = $data['name']; // please read the below note
       $this->zipcode  = $data['zipcode'];
       $this->email = $data['email'];
	   $this->username = $data['username'];
	  $result = $this->db->update('users',$this,array('id' => $id));
       if($result)
       {
           return "Data is updated successfully";
       }
       else
       {
           return "Error has occurred";
       }
 }
   public function delete($id){
   
       $result = $this->db->query("delete from `tbl_user` where user_id = $id");
       if($result)
       {
           return "Data is deleted successfully";
       }
       else
       {
           return "Error has occurred";
       }
   }

	}