<?php
class Product_model extends CI_Model{
		public function __construct(){
			$this->load->database();
		}

		public function get_products(){
			$this->db->order_by('created');
			$query = $this->db->get('products');
			return $query->result_array();
		}


		public function get_product($id){
			$query = $this->db->get_where('products', array('id' => $id));
			return $query->row();
		}

		public function delete_product($id){
			$this->db->where('id', $id);
			$this->db->delete('products');
			return true;
		}

		//select * from products where price between $price1 AND price2
		////order by price asc
		public function filter_products($limit1,$limit2){
			$this->db->where('price BETWEEN "'. $limit1. '" and "'. $limit2.'"');
			$this->db->order_by('created');
			$query = $this->db->get('products');
			return $query->result_array();
		}

	}