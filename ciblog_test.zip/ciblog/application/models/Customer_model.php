<?php
	class Customer_model extends CI_Model{
		//read all data from employees
		public function read(){
		   $query = $this->db->query("select * from customer_details");
		   return $query->result_array();
		}
	   public function getById($id){
			$query = $this->db->get_where('customer_details', array('id' => $id));
			$result =  $query->row_array();
			return $result;
	   }
   /* public function insert($data){
       
       $this->first_name    = $data['first_name']; // please read the below note
       $this->last_name  = $data['last_name'];
       $this->email = $data['email'];
	   $this->telephone_number = $data['telephone_number'];
	   $this->address = $data['address'];
	   $this->position_name = $data['position_name'];
       if($this->db->insert('employees',$this))
       {    
           return 'Data is inserted successfully';
       }
         else
       {
           return "Error has occured";
       }
   } */
   public function update($id,$data){
   
       $this->Customer_Type    = $data['Customer_Type']; // please read the below note
       $this->Date_Of_Birth  = $data['Date_Of_Birth'];
       $this->Date_Incorp = $data['Date_Incorp'];
	   $this->Registration_No = $data['Registration_No'];
	   $this->Address_Line_1 = $data['Address_Line_1'];
	   $this->Address_Line_2 = $data['Address_Line_2'];
	   $this->Town_City = $data['Town_City'];
	    $this->Country = $data['Country'];
		$this->Contact_Name = $data['Contact_Name'];
		$this->Contact_Number = $data['Contact_Number'];
		$this->Num_Shares = $data['Num_Shares'];
		$this->Share_Price = $data['Share_Price'];
		
		if( $this->Customer_Type === 'Corporate'){
			$this->Num_Shares = $data['Num_Shares'];
		}
       $result = $this->db->update('customer_details',$this,array('id' => $id));
       if($result)
       {
           return "Data is updated successfully";
       }
       else
       {
           return "Error has occurred";
       }
   }
   public function delete($id){
   
       $result = $this->db->query("delete from `employees` where id = $id");
       if($result)
       {
           return "Data is deleted successfully";
       }
       else
       {
           return "Error has occurred";
       }
   }
   
   public function get_customer_details(){
	      $query = $this->db->query("SELECT id,Contact_Name AS Customer_Name,if(Customer_Type='Individual',Date_Of_Birth,Date_Incorp) as DOB/DATE_Incorp,Num_Shares,Share_Price,(Num_Shares * Share_Price) AS Balance FROM customer_details
");
		   return $query->result_array();
   }
   public function showCustomer($keyword = null)
{
    if ($keyword === null) {
        return $this->db->get('customer_details')->result_array();
    } else {
        $this->db->select('*');
        $this->db->from('customer_details');
        if($keyword){
            $this->db->or_like('Contact_Name',$keyword);
        }
        $this->db->get()->result_array();
    }
}

	}