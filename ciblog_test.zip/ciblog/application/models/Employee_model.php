<?php
	class Employee_model extends CI_Model{
		//read all data from employees
		public function read(){
		   $query = $this->db->query("select * from employees");
		   return $query->result_array();
		}
	   public function getById($id){
			$query = $this->db->get_where('employees', array('id' => $id));
			$result =  $query->row_array();
			return $result;
	   }
   public function insert($data){
       
       $this->first_name    = $data['first_name']; // please read the below note
       $this->last_name  = $data['last_name'];
       $this->email = $data['email'];
	   $this->telephone_number = $data['telephone_number'];
	   $this->address = $data['address'];
	   $this->position_name = $data['position_name'];
       if($this->db->insert('employees',$this))
       {    
           return 'Data is inserted successfully';
       }
         else
       {
           return "Error has occured";
       }
   }
   public function update($id,$data){
   
       $this->first_name    = $data['first_name']; // please read the below note
       $this->last_name  = $data['last_name'];
       $this->email = $data['email'];
	   $this->telephone_number = $data['telephone_number'];
	   $this->address = $data['address'];
	   $this->position_name = $data['position_name'];
       $result = $this->db->update('employees',$this,array('user_id' => $id));
       if($result)
       {
           return "Data is updated successfully";
       }
       else
       {
           return "Error has occurred";
       }
   }
   public function delete($id){
   
       $result = $this->db->query("delete from `employees` where id = $id");
       if($result)
       {
           return "Data is deleted successfully";
       }
       else
       {
           return "Error has occurred";
       }
   }

	}