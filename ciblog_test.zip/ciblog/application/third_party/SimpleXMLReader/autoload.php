<?php

require dirname(__FILE__) . "/library/SimpleXMLReader.php";
